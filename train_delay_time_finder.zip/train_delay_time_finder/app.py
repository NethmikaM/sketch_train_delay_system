from flask import Flask, render_template, request
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.neighbors import KNeighborsRegressor

app = Flask(__name__)

# Load and preprocess data
data = pd.read_csv("train_delay_regression.csv")

encoders = {}
for col in ['train_name', 'route', 'weather']:
    le = LabelEncoder()
    data[col] = le.fit_transform(data[col])
    encoders[col] = le

X = data[['train_name', 'route', 'distance_km', 'departure_hour', 'temperature', 'weather']]
y = data['delay_minutes']
model = KNeighborsRegressor(n_neighbors=3)
model.fit(X, y)

# Route for UI front page
@app.route("/")
def home():
def home():
    return render_template("front_page.html")

# Route for Flask prediction page
@app.route("/index", methods=["GET", "POST"])
def index():
    delay = None

    if request.method == "POST":
        train_name = request.form['train_name']
        route = request.form['route']
        distance_km = int(request.form['distance_km'])
        departure_hour = int(request.form['departure_hour'])
        temperature = int(request.form['temperature'])
        weather = request.form['weather']

        new_train = pd.DataFrame([{
            "train_name": train_name,
            "route": route,
            "distance_km": distance_km,
            "departure_hour": departure_hour,
            "temperature": temperature,
            "weather": weather
        }])

        # Encode categorical columns
        for col in ['train_name', 'route', 'weather']:
            new_train[col] = encoders[col].transform(new_train[col])

        # Predict delay
        delay = model.predict(new_train)[0]

    return render_template("index.html", delay=round(delay, 1) if delay is not None else None)

if __name__ == "__main__":
    app.run(debug=True)
